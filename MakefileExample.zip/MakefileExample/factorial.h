#ifndef FACTORIAL_H
#define FACTORIAL_H

int factorial(int n);

#endif

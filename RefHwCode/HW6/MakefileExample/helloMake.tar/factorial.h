#ifndef FACTORIAL_H
#define FACTORIAL_H

void print_hello();
int factorial(int n);

#endif
